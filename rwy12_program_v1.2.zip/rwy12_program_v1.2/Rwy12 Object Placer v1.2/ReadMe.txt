Rwy12 ObjectPlacer v1.2 Program and Libraries
=============================================
Remember, in order for Rwy12 to work properly you have to download and install all 4 files;
rwy12_Program_v1.2.zip � 	the program with documentation
rwy12_Lib1_v1.2.zip � 		object libraries part 1
rwy12_Lib2_v1.2.zip � 		object libraries part 2
rwy12_Lib3_v1.2.zip � 		object libraries part 3

Please follow the installation instructions carefully (for your convinience they are in txt, word and PDF format). You will find in these files the credits to all the many people who took part in creating Rwy12 Object Placer. You will also find in the library downloads the txt files that came with the original libraries when they were published the first time.

You can search the forums on our web site for specific issues.

Please also read (at least the important parts) of the tutorial and Q&A in the Tutorials folder of the program zip (rwy12_Program_v1.2.zip)

Israel Roth and Seev Kahn
http://www.rwy12.com/
Aug. 2005


